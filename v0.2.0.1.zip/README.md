This Chrome extension will forward a YouTube url to XBMC so your Raspberry Pi will play it automatically.

[View on Chrome Store](https://chrome.google.com/webstore/detail/autopi/jlfjghdgdpbjgnaecdmbkdgmbhbfagmh)